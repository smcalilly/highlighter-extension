remove keyboard shortcut
login with popup logs in user of the app
better ui with popup -- i'm already logged in??!!