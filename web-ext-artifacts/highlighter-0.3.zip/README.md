# highlighter
This browser extension saves "highlights" or selected passages while reading in your favorite web browser. The extension sends the highlights to this Rails app: https://github.com/smcalilly/highlighter-rails

No matter what or where you read, your highlights are always available to reference whenever you need them.

Visit www.highlighter.online to sign up.
